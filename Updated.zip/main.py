from ui import CalculatorUI

def main():
    calc_ui = CalculatorUI()
    calc_ui.run()

if __name__ == "__main__":
    main()
